
import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author kevinguerra
 */
public class Candidate {
    private String firstName;
    private String lastName;
    private int[] votes = new int[]{1,2,3,4};
    

    public Candidate(){
        
        firstName = "none";
        lastName = "none";
        votes = null;
        generateRandomArray(votes);
    }
    
    public Candidate(String firstName,String lastName, int votes[]){
        
        this.firstName =firstName;
        this.lastName = lastName;
        this.votes = new int[]{1,2,3,4}; 
        //return votes * firstName * lastName;
        
    }
    
    
    
    Candidate(Candidate c){
        firstName = c.firstName;
        lastName = c.lastName;  
        votes = c.votes;
    }
    
    
    @Override
    public String toString(){
        String str = String.format("%12s%12s", firstName, lastName);
        return str;
        
    }   
    
    public static void generateRandomArray(int[] array) {
        Random gen = new Random();
        for(int i= 0; i<array.length; i++){
            array[i] = gen.nextInt(400);
        }
    }
   
    
    public static void bubblesort(int votes[]){
        int i, j, tmp;
        int size = votes.length;
        for (i = 1; i < size; i++){
            for (j = 0; j < size - i; j++){
               if(votes[j] > votes[j+1])
                  swap(votes, j, j+1);
            }
        }
    }
    public static void swap(int[] votes, int i, int j){
       int tmp = votes[i];
        votes[i] = votes[j];
        votes[j] = tmp;
    }
    public static int indexOfSmallest(int[] votes, int first, int last){
        int min = votes[first];
        int indexOfMin = first;
        for (int k = first+1; k <= last; k++){
            if (votes[k] < min){
                min = votes[k];
                indexOfMin = k;
            }
        }
        return indexOfMin;
        
    }   
    
    public static void selectionSort(int[] votes){
        int i, j, indexOfMin;
        int size = votes.length;
        for(i = 0; i<size-1; i++){
            indexOfMin = indexOfSmallest(votes, i, size-1);
            swap(votes,i,indexOfMin);
        }
    }
    
}
    
    