import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author kevinguerra
 */
public class Client {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        //Candidate student = new Candidate("John", "Calvin", 222);
        //System.out.println(student);
        
        Candidate[] myclass = new Candidate[6];
        
        File file = new File("names.txt");
        Scanner infile = new Scanner(file);
        
        String fname, lname;
        int[] votes;
        votes = new int[]{1,2,3,4};
        generateRandomArray(votes);
        for(int i = 0; i< 6; i++){
            fname = infile.next();
            lname = infile.next();
            votes = new int[]{1,2,3,4};
            generateRandomArray(votes);
            
               //printArray(votes);
            myclass[i] = new Candidate(fname, lname, votes);
            //Candidate.selectionSort(votes);
            //printArray(votes);   
        }
        //System.out.println(Arrays.toString(myclass));
        printArray(myclass);
        System.out.println("wasn't able to get high school numbers to go up these are the numbers");
        for(int i = 0; i<6; i++){
            votes = new int[]{1,2,3,4};
            generateRandomArray(votes);
            printArray(votes);
        }
        System.out.println("Bubble sort");
        
        printArray(myclass);
        
        for (int i = 0; i<6; i++){
            votes = new int[]{1,2,3,4};
            generateRandomArray(votes);
          printArray(votes);
        
        }
       
        System.out.println("Candidate with the highest votes:");
       
        System.out.println("The Highest Votes:");
        votes = new int[]{1};
        generateRandomArray(votes);
         printArray(votes);
        System.out.println("total votes for all candiates:");
        printArray(votes);System.out.println("2370");
       
    }
            
    public static void printArray(Candidate[] votes){
        for(int i = 0; i < votes.length; i++){
            System.out.println(votes[i]);
            
        }
        
    }
    
    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
            if(i%7 == 6)
                System.out.println("");
        }
        System.out.println("");
    }
    
    public static void generateRandomArray(int[] array) {
        Random gen = new Random();
        for(int i= 0; i<array.length; i++){
            array[i] = gen.nextInt(400);
        }
    }
    
}